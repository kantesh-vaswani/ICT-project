// Cart functions used on every page. The cart is saved in the browser (localStorage).
function getCart() {
  return JSON.parse(localStorage.getItem("cart")) || [];
}

function saveCart(cart) {
  localStorage.setItem("cart", JSON.stringify(cart));
  updateCartCount();
}

function addToCart(id, size) {
  var cart = getCart();
  for (var i = 0; i < cart.length; i++) {
    if (cart[i].id === id && cart[i].size === size) {
      cart[i].qty++;          // same item and size: just add one more
      saveCart(cart);
      return;
    }
  }
  cart.push({ id: id, size: size, qty: 1 });
  saveCart(cart);
}

function updateCartCount() {
  var total = 0;
  var cart = getCart();
  for (var i = 0; i < cart.length; i++) {
    total += cart[i].qty;
  }
  var badge = document.getElementById("cart-count");
  if (badge) {
    badge.textContent = total;
  }
}

// ----- Cart page only -----
function showCart() {
  var box = document.getElementById("cart-items");
  if (!box) return;           // not on the cart page

  var cart = getCart();
  if (cart.length === 0) {
    box.innerHTML = '<p class="empty">Your cart is empty. <a href="catalog.html">Browse the catalog</a> to add items.</p>';
    document.getElementById("cart-total").textContent = "0";
    return;
  }

  var html = "";
  var total = 0;
  for (var i = 0; i < cart.length; i++) {
    var p = getProductById(cart[i].id);
    var lineTotal = p.price * cart[i].qty;
    total += lineTotal;
    html += '<div class="cart-row">' +
      '<div class="cart-icon" style="background:' + p.color + '">' + p.icon + '</div>' +
      '<div class="cart-info"><h3>' + p.name + '</h3><p>Size: ' + cart[i].size + ' | Rs. ' + p.price.toLocaleString() + '</p></div>' +
      '<div class="qty">' +
      '<button onclick="changeQty(' + i + ', -1)">-</button>' +
      '<span>' + cart[i].qty + '</span>' +
      '<button onclick="changeQty(' + i + ', 1)">+</button></div>' +
      '<p class="line-total">Rs. ' + lineTotal.toLocaleString() + '</p>' +
      '<button class="remove" onclick="removeItem(' + i + ')">Remove</button>' +
      '</div>';
  }
  box.innerHTML = html;
  document.getElementById("cart-total").textContent = total.toLocaleString();
}

function changeQty(index, change) {
  var cart = getCart();
  cart[index].qty += change;
  if (cart[index].qty < 1) {
    cart.splice(index, 1);
  }
  saveCart(cart);
  showCart();
}

function removeItem(index) {
  var cart = getCart();
  cart.splice(index, 1);
  saveCart(cart);
  showCart();
}

function checkout() {
  if (getCart().length === 0) {
    alert("Your cart is empty.");
    return;
  }
  alert("Thank you! This is a demo, so no real order was placed.");
  saveCart([]);
  showCart();
}

updateCartCount();
showCart();
