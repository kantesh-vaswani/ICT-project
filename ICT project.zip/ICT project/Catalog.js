var currentCategory = "All";

function showProducts() {
  // 1. filter
  var list = [];
  for (var i = 0; i < products.length; i++) {
    if (currentCategory === "All" || products[i].category === currentCategory) {
      list.push(products[i]);
    }
  }

  // 2. sort
  var sortValue = document.getElementById("sort").value;
  if (sortValue === "low") {
    list.sort(function (a, b) { return a.price - b.price; });
  } else if (sortValue === "high") {
    list.sort(function (a, b) { return b.price - a.price; });
  } else if (sortValue === "name") {
    list.sort(function (a, b) { return a.name.localeCompare(b.name); });
  }

  // 3. show
  var html = "";
  for (var j = 0; j < list.length; j++) {
    html += makeCard(list[j]);
  }
  document.getElementById("product-grid").innerHTML = html;
  document.getElementById("result-count").textContent = list.length + " items";
}

function setCategory(category) {
  currentCategory = category;
  var tabs = document.querySelectorAll(".tab");
  for (var i = 0; i < tabs.length; i++) {
    tabs[i].classList.remove("active");
    if (tabs[i].getAttribute("data-cat") === category) {
      tabs[i].classList.add("active");
    }
  }
  showProducts();
}

var params = new URLSearchParams(window.location.search);
setCategory(params.get("cat") || "All");
