// Contact form: check the fields, then show a thank-you message
function sendForm(event) {
  event.preventDefault();     // stop the page from reloading

  var name = document.getElementById("name").value.trim();
  var email = document.getElementById("email").value.trim();
  var message = document.getElementById("message").value.trim();
  var feedback = document.getElementById("form-feedback");

  if (name === "" || email === "" || message === "") {
    feedback.textContent = "Please fill in all fields.";
    feedback.className = "error";
  } else if (email.indexOf("@") === -1 || email.indexOf(".") === -1) {
    feedback.textContent = "Please enter a valid email address.";
    feedback.className = "error";
  } else {
    feedback.textContent = "Thank you, " + name + "! We have received your message.";
    feedback.className = "success";
    document.getElementById("contact-form").reset();
  }
}
