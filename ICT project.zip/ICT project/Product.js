// Product details page: reads the id from the address (product.html?id=3)
var params = new URLSearchParams(window.location.search);
var product = getProductById(Number(params.get("id")));
var selectedSize = "";

if (!product) {
  document.getElementById("details").innerHTML = '<p class="empty">Product not found. <a href="catalog.html">Back to catalog</a></p>';
} else {
  document.title = product.name + " - Fab Fashion";
  document.getElementById("p-img").style.background = product.color;
  document.getElementById("p-img").textContent = product.icon;
  document.getElementById("p-category").textContent = product.category;
  document.getElementById("p-name").textContent = product.name;
  document.getElementById("p-price").textContent = "Rs. " + product.price.toLocaleString();
  document.getElementById("p-desc").textContent = product.description;

  var sizeHtml = "";
  for (var i = 0; i < product.sizes.length; i++) {
    sizeHtml += '<button class="size" onclick="chooseSize(this)">' + product.sizes[i] + '</button>';
  }
  document.getElementById("p-sizes").innerHTML = sizeHtml;
}

function chooseSize(button) {
  var all = document.querySelectorAll(".size");
  for (var i = 0; i < all.length; i++) {
    all[i].classList.remove("selected");
  }
  button.classList.add("selected");
  selectedSize = button.textContent;
  document.getElementById("message").textContent = "";
}

function addClicked() {
  var message = document.getElementById("message");
  if (selectedSize === "") {
    message.textContent = "Please select a size first.";
    message.className = "error";
    return;
  }
  addToCart(product.id, selectedSize);
  message.textContent = "Added to cart!";
  message.className = "success";
  var imgSrc = (Array.isArray(product.images) && product.images[0]) || product.image || "";
var pImgEl = document.getElementById("p-img");
pImgEl.style.background = product.color;

if (imgSrc && /\.(webp|png|jpe?g|gif)$/i.test(imgSrc)) {
  pImgEl.innerHTML = '<img src="' + imgSrc + '" alt="' + product.name + '">';
} else {
  pImgEl.textContent = product.icon || "";
}
var imgSrc = (Array.isArray(product.images) && product.images[0]) || product.image || "";
var pImgEl = document.getElementById("p-img");
pImgEl.style.background = product.color;

}
