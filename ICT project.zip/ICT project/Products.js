// All product data lives here. Add or edit products in this array.
var products = [
  {
  id: 1,
  name: "Cotton Kurta",
  category: "Men",
  price: 3500,
  sizes: ["S", "M", "L", "XL"],
  image: "kurta.jpg",
  images: ["kurta.jpg"],
  icon: "👕",
  color: "#d9e4dd",
  description: "Soft cotton kurta for everyday wear. Breathable and easy to wash."
} , 
  {
    id: 2,
    name: "Denim Jacket",
    category: "Men",
    price: 6200,
    sizes: ["M", "L", "XL"],
    image: "denim.jpg",
    images: ["denim.jpg"],
    icon : "🧥" , 
    color: "#cfd8e6",
    description: "Classic blue denim jacket with a regular fit and metal buttons."
  },
  {
    id: 3,
    name: "Polo T-Shirt",
    category: "Men",
    price: 2400,
    sizes: ["S", "M", "L", "XL"],
    image: "polo.jpg",
    images: ["polo.jpg"],
    icon: "👕",
    color: "#e8e1d0",
    description: "Plain polo shirt made from pique cotton. Goes with jeans or trousers."
  },
  {
    id: 4,
    name: "Winter Shawl Set",
    category: "Women",
    price: 7800,
    sizes: ["S", "M", "L"],
    image: "shawl.jpg",
    images: ["shawl.jpg"],
    icon: "🧣",
    color: "#ecd9d9",
    description: "Warm embroidered shawl with a matching shirt for cold evenings."
  },
  {
    id: 5,
    name: "Lawn 3-Piece Suit",
    category: "Women",
    price: 5900,
    sizes: ["S", "M", "L"],
    image: "lawn.jpg",
    images: ["lawn.jpg"],
    icon: "👗",
    color: "#f1e3c6",
    description: "Printed lawn shirt, dupatta and trousers. Light and cool for summer."
  },
  {
    id: 6,
    name: "Casual Kurti",
    category: "Women",
    price: 3100,
    sizes: ["XS", "S", "M", "L"],
    image: "kurti.jpg",
    images: ["kurti.jpg"],
    icon: "👚",
    color: "#dcd6ea",
    description: "Short kurti with a simple neckline, made for college and office."
  },
  {
    id: 7,
    name: "Embroidered Dupatta",
    category: "Women",
    price: 2800,
    sizes: ["Free"],
    icon: "🧵",
    image: "dupata.jpg",
    images: ["dupata.jpg"],
    color: "#e6d3e0",
    description: "Long chiffon dupatta with hand-style embroidery on the border."
  },
  {
    id: 8,
    name: "Kids Shalwar Kameez",
    category: "Kids",
    price: 2200,
    sizes: ["4Y", "6Y", "8Y"],
    image: "kidssk.jpg",
    images: ["kidssk.jpg"],
    icon: "🧒",
    color: "#d6e8e0",
    description: "Comfortable shalwar kameez for boys, perfect for Eid and family events."
  },
  {
    id: 9,
    name: "Girls Frock",
    category: "Kids",
    price: 2600,
    sizes: ["4Y", "6Y", "8Y"],
    image: "frock.jpg",
    images: ["frock.jpg"],
    icon: "👧",
    color: "#f2d8dc",
    description: "Pretty cotton frock with a flared skirt and soft lining."
  },
  {
    id: 10,
    name: "Kids Hoodie",
    category: "Kids",
    price: 1900,
    sizes: ["6Y", "8Y", "10Y"],
    image: "khoodie.jpg",
    images: ["khoodie.jpg"],
    icon: "🧥",
    color: "#d9dff0",
    description: "Fleece hoodie that keeps kids warm at school and the park."
  },
  {
    id: 11,
    name: "Kids Pajama Set",
    category: "Kids",
    price: 1500,
    sizes: ["4Y", "6Y", "8Y"],
    image: "kpajama.jpg",
    images: ["kpajama.jpg"],
    icon: "🌙",
    color: "#e1dcef",
    description: "Two-piece cotton night suit with a fun print."
  },
  {
    id: 12,
    name: "Formal Waistcoat",
    category: "Men",
    price: 4800,
    sizes: ["M", "L", "XL"],
    image: "formal.jpg",
    images: ["formal.jpg"],
    icon: "🦺",
    color: "#d8d3c8",
    description: "Tailored waistcoat that looks sharp over a kurta or shirt."
  }
];

function getProductById(id) {
  for (var i = 0; i < products.length; i++) {
    if (products[i].id === id) {
      return products[i];
    }
  }
}

function getProductImages(p) {
  if (Array.isArray(p.images) && p.images.length > 0) {
    return p.images;
  }
  if (p.image) {
    return [p.image];
  }
  return p.icon ? [p.icon] : [];
}

function isImageFile(value) {
  return typeof value === "string" && /\.(webp|png|jpe?g|gif)$/i.test(value);
}

function renderMediaItem(value, altText) {
  if (isImageFile(value)) {
    return '<img src="' + value + '" alt="' + altText + '">';
  }
  return value || "";
}

function makeCard(p) {
  var imgs = getProductImages(p);
  var mediaHtml = imgs.length > 0 ? renderMediaItem(imgs[0], p.name) : "";

  return '<div class="card">' +
    '<a href="product.html?id=' + p.id + '">' +
    '<div class="card-img" style="background:' + p.color + '">' + mediaHtml + '</div></a>' +
    '<div class="card-body">' +
    '<span class="badge">' + p.category + '</span>' +
    '<h3>' + p.name + '</h3>' +
    '<p class="price">Rs. ' + p.price.toLocaleString() + '</p>' +
    '<a class="btn small" href="product.html?id=' + p.id + '">View details</a>' +
    '</div></div>';
}